

//用户名输入验证
var uname =document.getElementById('uname');
uname.onblur=function(){
	var val=uname.value;
	if(val===""){
		// nextElementSibling属性只返回元素节点之后的兄弟元素节点（不包括文本节点、注释节点）
		this.nextElementSibling.innerHTML="用户名不能为空"
		this.nextElementSibling.className='help-block bg-danger';
	}else if(val.length<3||val.length>9){
		this.nextElementSibling.innerHTML="用户名大于3位小于6位";
		this.nextElementSibling.className='help-block bg-danger';
	}else{
		this.nextElementSibling.innerHTML="用户名输入正确";
		this.nextElementSibling.className='help-block bg-success';
	}
}

//密码
// onblur 的事件会在对象失去焦点时发生。
upwd.onblur=function(){
	// valueMissing：输入值为空时
	if(this.validity.valueMissing){
		this.nextElementSibling.innerHTML='密码不能为空';
		// 修改ClassName改样式
		this.nextElementSibling.className='help-block bg-danger';
		// **tooLong：**超过maxLength最大限制
	}else if(this.validity.tooShort){
		this.nextElementSibling.innerHTML='密码不能少于6位';
		this.nextElementSibling.className='help-block bg-danger';
	}else {
		this.nextElementSibling.innerHTML='密码输入正确';
		this.nextElementSibling.className='help-block bg-success';
	}

}
// valueMissing前提具有required 输入为空时候返回true。
//-------------->用户名和密码此处必须在html中写required不然不填不走第一个if（配套）




//对邮箱进行验证
var email = document.getElementById("email");
email.onblur = function(){
	// **typeMismatch：**控件值与预期类型不匹配
	if(this.validity.typeMismatch || this.validity.valueMissing){
		// // nextElementSibling属性只返回元素节点之后的兄弟元素节点（不包括文本节点、注释节点）
			this.nextElementSibling.innerHTML='邮箱格式不正确';
			this.nextElementSibling.className='help-block bg-danger';
			// setCustomValidity用于判断表单的正误，有错误时可以手动设置提示信息
			// 当没有错误时要将setCustomValidity(“)设置为空，否则表单无法提交
			this.setCustomValidity('请输入xx@xx.cn/com');
	}else{
			this.nextElementSibling.innerHTML='邮箱格式正确';
			this.nextElementSibling.className='help-block bg-success';
			this.setCustomValidity('');
	}
}



// 背景
function hasClass(obj, cn) {
	//  /b边界
	var reg = new RegExp("\\b" + cn + "\\b");
	return reg.test(obj.claasName);
}

function addClass(obj, cn) {
	if(!obj.className){
		obj.className = cn;
	}
	if(!hasClass(obj, cn)){
		obj.className += " " + cn;
		//加空格与前面隔开 b1b2 -> b1 b2;
	}
}


var div = document.getElementById("bg");
var box = div.getElementsByTagName("div");                 
for(var i=0; i < box.length; i++){
	addClass(box[i],"light");         
}


var light = document.querySelectorAll(".light");
for(var i=0; i < light.length; i++){
	var a = Math.random()*50;
	light[i].style.width = a+"px";
	light[i].style.height = a+"px",
	// Math.random()//返回一个小于1的随机数（不包含1）
	// vh 指可视窗口的高度 浏览器高度900px, 1 vh = 900px/100 = 9 px。
	light[i].style.top = Math.random()*100+"vh";
	light[i].style.left = Math.random()*1000+"vh";
	light[i].style.background = "rgba("+Math.random()*255+","+Math.random()*255+","+Math.random()*255+","+Math.random()*1+")";
	light[i].style.boxshadow = "0 0"+Math.random()*100+"px rgba("+Math.random()*255+","+Math.random()*255+","+Math.random()*255+","+Math.random()*1+")";
}

var w=0;
var timer1 = setInterval(function(){
	light[w].style.animation = "moveX 6s linear infinite";
	box[w].style.animation = "moveY 30s linear infinite";
	w++;
	if(W>=box.length){
		clearInterval(timer1);
	}
},10);





























