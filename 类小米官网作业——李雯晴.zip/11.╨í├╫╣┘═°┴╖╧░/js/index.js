// tools
function getStyle(obj, name){
    if(window.getComputedStyle){
        return getComputedStyle(obj, null)[name];
    }
    else{
        return obj.currentStyle[name];
    }
}

function move(obj, attr, target, speed, callback){
    clearInterval(obj.timer);
    var current = parseInt(getStyle(obj,attr));
    if(current > target){
        speed = -speed;
    }
    obj.timer = setInterval(function(){
        var oldValue = parseInt(getStyle(obj,attr));
        var newValue = oldValue + speed;
        if( (speed < 0 && newValue < target) || (speed > 0 && newValue > target) ){
            newValue = target;
        }
        obj.style[attr] = newValue + "px";

        if(newValue == target){
            clearInterval(obj.timer);
            callback && callback();
        }
    },40);
}

function hasClass(obj, cn) {
	//  /b边界
	var reg = new RegExp("\\b" + cn + "\\b");
	return reg.test(obj.className);
}

function addClass(obj, cn) {
	if(!hasClass(obj, cn)){
		obj.className += " " + cn;
		//加空格与前面隔开 b1b2 -> b1 b2;
	}
}

function removeClass(obj, cn) {
    if(!obj.className){
		return;
	}
    var reg = new RegExp("\\b" + cn + "\\b");
    obj.className = obj.className.replace(reg, "");
}




// banner
var imgList = document.getElementById("img-list");
var imgArr = imgList.getElementsByTagName("img");  
var pointer = document.getElementById("pointer");
var index1 = 0;
var allA = pointer.getElementsByTagName("a");
imgArr[0].style.opacity = 1;
allA[index1].style.backgroundColor = "rgba(255, 255, 255, 0.4)";
allA[index1].style.borderColor = "rgba(0, 0, 0, 0.4)";
for(var i=0; i<allA.length; i++){
     // 不能直接用i
    allA[i].num = i;
    allA[i].onclick = function(){
        clearInterval(timer1);
        index1 = this.num;
        SetBanner();  
        //开启计时器
        autoChang();         
    }
}

    //改变画面 
function SetBanner(){
    if(index1 < 0){
        index1 = imgArr.length-1;
    }
    index1 = index1 % imgArr.length;
    for(var i=0; i<imgArr.length; i++){
        // 内联样式最大 ，所以要把它设为空，css里面的样式才会生效；
        allA[i].style.backgroundColor = "";
        allA[i].style.borderColor = "";
        imgArr[i].style.opacity = 0;
    }
    imgArr[index1].style.opacity = 1;
    allA[index1].style.backgroundColor = "rgba(255, 255, 255, 0.4)";
    allA[index1].style.borderColor = "rgba(0, 0, 0, 0.4)";
}

var timer1;
autoChang();
// 自动
function autoChang() {
    timer1 = setInterval(function(){
        index1++;
        SetBanner();
    },3000);
}

var prev = document.querySelector('.prev');
prev.onclick = function(){
    clearInterval(timer1);
    index1--;
    SetBanner();
    autoChang();
}

var next = document.querySelector('.next');
next.onclick = function () { 
    clearInterval(timer1);
    index1++;
    SetBanner();
    autoChang();
}



// 搜索框search-inp
var searchInp = document.getElementById("search-inp");
var searchinp = ["618夏日入新互动参与赢好礼","【以旧换新】至高补贴3000元","【轻装上阵】运动套装","小米11","空调","日用百货","家电"];
var index2 = 0;
searchInp.placeholder = searchinp[0];
timer2 = setInterval(function(){
    index2++;
    index2 = index2%searchinp.length;
    searchInp.placeholder = searchinp[index2];
},2000);
searchInp.parentNode.onclick = function () {
    searchInp.disabled = false;
    searchInp.focus();
}


 //中间导航条
var showGoods = document.querySelectorAll(".show-goods");
var goodsInfoUl = document.getElementById("goods-info-ul");
var goodsInfoImg = goodsInfoUl.getElementsByTagName("img");
var goodsInfoImgArr = [["../img/小米1.webp","../img/小米2.webp","../img/小米3.webp","../img/小米4.webp","../img/小米5.webp","../img/小米6.webp"],
["../img/红米1.webp","../img/红米2.webp","../img/红米3.webp","../img/红米4.webp","../img/红米5.webp","../img/红米6.webp"]];

var goodsInfoP = document.querySelectorAll(".goods-info-p");
var goodsInfoPArr =[["小米MIX FOLD","小米11 Ultra","小米11 Pro","小米11 青春版","小米11S","小米11"],
["Note 10 Pro","Redmi Note 10 5G","K40 游戏增强版","K40 Pro 系列","Redmi K40","Redmi Note 9 系列"]];

var goodsInfoColor = document.querySelectorAll(".goods-info-color");
goodsInfoColorArr = [["9999元起","5499元起","4499元起","2299元起","2999元起","3799元起"],
["1599元起","999元起","1999元起","2499元起","1999元起","899元起"]];

            // 2应该为showGoods的length
for(var i=0; i < 2; i++){
    // 不能直接用i
    showGoods[i].num = i;
    showGoods[i].onmouseover = function(){
        for(var j=0; j < goodsInfoImg.length; j++){
            goodsInfoImg[j].src = goodsInfoImgArr[this.num][j];
            goodsInfoP[j].innerHTML = goodsInfoPArr[this.num][j];
            goodsInfoColor[j].innerHTML = goodsInfoColorArr[this.num][j];
        }
    }
}


// 小米秒杀
// img部分
var miaoshaImg = document.getElementById("miaosha-img");
var miaoshaImgArr = document.querySelectorAll('.miaosha1');
miaoshaImg.style.width = (miaoshaImgArr.length)*1226 + "px";

var miaoshaleft = document.getElementById("miaoshaleft");
var miaosharight = document.getElementById("miaosharight");

var index3 = 0;

function aomiaoshaimg(){
    timer3 = setInterval(function(){
        index3++;
        if(index3 >= miaoshaImgArr.length - 1){
            index3 = 0;
            miaoshaImg.style.left = 249 +"px";
        }
        move(miaoshaImg, "left", 249-998*index3, 50, function () {
        });
    },3000);
}
aomiaoshaimg();

miaosharight.onclick = function(){
    index3++;
    clearInterval(timer3); 
    if(index3 >= miaoshaImgArr.length - 1){
        index3 = 0;
        miaoshaImg.style.left = 249 +"px";
    }
    move(miaoshaImg, "left", 249-998*index3, 100, function () {
        aomiaoshaimg();
    });
}
miaoshaleft.onclick = function () { 
    index3--;
    clearInterval(timer3);
    if(index3 < 0){
        index3 = miaoshaImgArr.length - 2;
        miaoshaImg.style.left = 249-998*index3 + "px";
    }
    move(miaoshaImg, "left", 249-998*index3, 100, function () {
        aomiaoshaimg();
    });
}
// 时钟部分
var hour = document.getElementById("hour");
var min = document.getElementById("min");
var second = document.getElementById("second");
var deadline = new Date();
var today = deadline.getDate();
deadline = new Date('2021-6-' + today + ' 22:00');
function countdowm(){
    var now = new Date();
    var timeRemaining = deadline - now;
    if(timeRemaining < 0){
        return 0;
    }
    var second1 = Math.floor(timeRemaining / 1000 %60);
    var min1 = Math.floor(timeRemaining / 1000 /60 %60);
    var hour1 = Math.floor(timeRemaining / 1000 /60 /60 %24);
    hour.innerHTML = hour1;
    min.innerHTML = min1;
    second.innerHTML = second1;
}
setInterval(countdowm,1000);



// 固定定位的工具条的变化
// 响应式变化
var backTopWrapper = document.querySelector(".back-top-wrapper");
function backTopFun(){
    var screenWith = document.body.offsetWidth;
    if(screenWith < 1226){
        addClass(backTopWrapper,"back-top-in");    
    }
    else{
        removeClass(backTopWrapper,"back-top-in")
    }
}
setInterval(backTopFun,10);

// 弹出字
var backTop = document.getElementById("back-top");
var backTopArr = backTop.getElementsByTagName("li");
var backTopHidArr = backTop.getElementsByTagName("div");
for(var i=1; i < backTopArr.length; i++){
    backTopArr[i].num = i;
    backTopArr[i].onmouseover = function(){
        for(var j=1; j < backTopArr.length; j++){
            backTopHidArr[j].style.visibility = "";
        }
        backTopHidArr[this.num].style.visibility = "visible";
    }
    backTopArr[i].onmouseout = function(){
        for(var j=1; j < backTopArr.length; j++){
            backTopHidArr[j].style.visibility = "";
        }
    }
}




// 搭配title
var pdMatchTitle = document.getElementById("pd-match-title");
var pdMatchTitleArr = pdMatchTitle.getElementsByTagName("li");
for(var i=0; i < pdMatchTitleArr.length; i++){
    pdMatchTitleArr[i].num = i;
    pdMatchTitleArr[i].onmouseover = function(){
        for(var j=0; j < pdMatchTitleArr.length; j++){
            removeClass(pdMatchTitleArr[j],"top-in");
        }
        addClass(pdMatchTitleArr[this.num],"top-in");
    }
}



// 最底部
var ftRt = document.getElementById("ft-rt");
var ftRtArr = ftRt.getElementsByTagName("img");

function footerImgChang(){
    var timer4 = setInterval(function(){
        // timer4本来就是打开的，所以不用再开了！
        clearInterval(timer5);
        ftRtArr[4].src = "../img/版权5（2）.png";
        var timer5 = setInterval(function(){
            // 两个都要关，开一次setInterval，timer的值不一样！
            // 所以要及时的关闭！
            clearInterval(timer4);
            clearInterval(timer5);
            ftRtArr[4].src = "../img/版权5.png";
            footerImgChang();
        },2000);
    },4000);
    // 4秒之后才运行timer4的setInterval
}
footerImgChang();
