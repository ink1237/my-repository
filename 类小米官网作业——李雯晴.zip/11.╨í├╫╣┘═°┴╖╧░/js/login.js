
var logoButton =document.getElementById('logo-button');

logoButton.onclick=function(){
   location.href="../html/index.html";
}